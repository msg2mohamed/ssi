
import React from 'react';
import { FileText, CreditCard, Printer, Smartphone } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: FileText,
      title: "Document Services",
      description: "Professional document preparation and processing"
    },
    {
      icon: CreditCard,
      title: "Online Applications",
      description: "Assistance with various government and private online applications"
    },
    {
      icon: Printer,
      title: "Printing & Scanning",
      description: "High-quality printing, scanning, and photocopying services"
    },
    {
      icon: Smartphone,
      title: "Digital Services",
      description: "Mobile recharge, bill payments, and other digital services"
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            E-Sevai Services
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We provide comprehensive e-governance and digital services to make your 
            life easier with professional assistance and support.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 text-center group hover:-translate-y-2"
            >
              <div className="bg-blue-100 rounded-full p-6 w-20 h-20 mx-auto mb-6 group-hover:bg-blue-600 transition-colors">
                <service.icon className="h-8 w-8 text-blue-600 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-blue-600 rounded-2xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">Need Help with E-Sevai Services?</h3>
          <p className="text-blue-100 mb-6">
            Visit our center for professional assistance with all your digital service needs.
          </p>
          <div className="text-lg font-semibold">
            📍 106, ABT Complex, Dindigul Road, Palani
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
