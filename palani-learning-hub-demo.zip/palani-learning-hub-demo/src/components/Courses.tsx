
import React from 'react';
import { BookOpen, Calculator, FileText, Globe, Keyboard, Monitor } from 'lucide-react';

const Courses = () => {
  const courses = [
    {
      icon: Keyboard,
      title: "Typewriting Classes",
      description: "Professional typing skills in both Tamil and English",
      features: ["Tamil Typing", "English Typing", "Speed Enhancement", "Accuracy Training"],
      color: "bg-blue-500"
    },
    {
      icon: Monitor,
      title: "Computer Basics",
      description: "Fundamental computer skills for beginners",
      features: ["Hardware Basics", "Software Usage", "File Management", "Internet Basics"],
      color: "bg-green-500"
    },
    {
      icon: Calculator,
      title: "Tally Course",
      description: "Complete accounting software training",
      features: ["Tally Prime", "GST Filing", "Inventory Management", "Financial Reports"],
      color: "bg-purple-500"
    },
    {
      icon: FileText,
      title: "COA (Computer on Application)",
      description: "Comprehensive computer application course",
      features: ["MS Office", "Data Entry", "Email Management", "Digital Documentation"],
      color: "bg-orange-500"
    },
    {
      icon: BookOpen,
      title: "DCA (Diploma in Computer Application)",
      description: "Complete diploma program in computer applications",
      features: ["Programming Basics", "Database Management", "Web Development", "Project Work"],
      color: "bg-indigo-500"
    },
    {
      icon: Globe,
      title: "Spoken English",
      description: "Improve your English communication skills",
      features: ["Grammar", "Vocabulary", "Conversation", "Pronunciation"],
      color: "bg-red-500"
    }
  ];

  return (
    <section id="courses" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Courses
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose from our comprehensive range of courses designed to enhance your 
            digital skills and career prospects.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-shadow duration-300 border border-gray-100 overflow-hidden"
            >
              <div className={`${course.color} p-6 text-white`}>
                <course.icon className="h-12 w-12 mb-4" />
                <h3 className="text-xl font-bold mb-2">{course.title}</h3>
                <p className="text-white/90">{course.description}</p>
              </div>
              
              <div className="p-6">
                <h4 className="font-semibold text-gray-900 mb-3">Course Features:</h4>
                <ul className="space-y-2">
                  {course.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-600">
                      <div className="h-2 w-2 bg-blue-600 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="mt-6 w-full bg-gray-900 hover:bg-gray-800 text-white py-3 rounded-lg font-semibold transition-colors">
                  Enquire Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Courses;
