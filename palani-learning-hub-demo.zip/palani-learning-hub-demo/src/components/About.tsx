
import React from 'react';
import { User, Mail, Phone, MapPin } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            About SSI Academy
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Leading computer education institute in Palani, dedicated to providing quality education 
            and practical skills that prepare students for the digital future.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=400&fit=crop"
              alt="SSI Academy"
              className="rounded-2xl shadow-2xl"
            />
          </div>
          
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Our Mission</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              At SSI Academy, we are committed to providing comprehensive computer education, 
              typewriting skills, and professional development courses. Our goal is to bridge 
              the digital divide and empower students with the knowledge and skills needed to 
              succeed in today's technology-driven world.
            </p>
            
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h4 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <User className="h-6 w-6 text-blue-600 mr-2" />
                Meet Our CEO
              </h4>
              <div className="space-y-3">
                <p className="text-gray-700">
                  <strong>Sathis Kumar S</strong> - Chief Executive Officer
                </p>
                <div className="flex items-center text-gray-600">
                  <Mail className="h-4 w-4 mr-2 text-blue-600" />
                  <span>ssiacademypln@gmail.com</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Phone className="h-4 w-4 mr-2 text-blue-600" />
                  <span>+91 98945 85484</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="h-4 w-4 mr-2 text-blue-600" />
                  <span>106, ABT Complex, Dindigul Road, Palani</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
